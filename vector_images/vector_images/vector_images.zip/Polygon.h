#pragma once
#include "Figure.h"

/// <summary>
/// This class represents an SVG polygon and inherits the Figure class
/// </summary>

class Polygon : public Figure
{
private:
	vector<Point> points_of_polygon;
	string contour_color;
	string filling_color;

public:
	Polygon();
	Polygon(vector<Point>& points, string contour_color, string filling_color);

	//set points of polygon
	void set_polygon(vector<Point>& points);
	//get points of polygon
	vector<Point> get_polygon() const;
	//set polygon contour color
	void set_contour_color(string& contour_color);
	//set polygon filling color
	void set_filling_color(string& filling_color);
	//get contour color
	string get_contour_color() const;
	//get filling color
	string get_filling_color() const;

	//translate polygon by horizontal and vertical
	virtual void translate(double horizontal, double vertical) override;
	//rotate polygon by angle
	virtual void rotate(int angle) override;
	//scale polygon by x and y
	virtual void scale(int width_x, int width_y) override;
	//print polygon
	virtual void print() const override;
	//translates polygon to SVG format
	virtual string to_SVG() override;
	//clone object
	virtual Figure* clone() const override;
};

/// <summary>
/// This class represents polygon creation and inherits the FigureCreator class
/// </summary>

class PolygonCreator : public FigureCreator
{
public:
	PolygonCreator() : FigureCreator("polygon") {};
	virtual Figure* create_figure(istream& is) const override;

};


